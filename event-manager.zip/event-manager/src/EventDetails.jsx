import React from 'react';

const EventDetails = ({ event }) => {
  return (
    <div>
      <h2>Event Details</h2>
      <p><strong>Title:</strong> {event.title}</p>
      <p><strong>Date:</strong> {event.date}</p>
      <p><strong>Time:</strong> {event.time}</p>
      <p><strong>Description:</strong> {event.description}</p>
      <p><strong>Organizer:</strong> {event.organizer}</p>
      <p><strong>Location:</strong> {event.location}</p>
    </div>
  );
};

export default EventDetails;