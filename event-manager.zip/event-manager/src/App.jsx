import React, { useState, useEffect } from 'react';
import EventList from './EventList';
import EventForm from './EventForm.jsx';
import EventDetails from './EventDetails.jsx';
import './App.css';

const App = () => {
  const [events, setEvents] = useState([]);
  const [selectedEvent, setSelectedEvent] = useState(null);

  useEffect(() => {
    fetch('http://localhost:3000/events')
      .then((response) => response.json())
      .then((data) => setEvents(data));
  }, []);

  const addEvent = (event) => {
    fetch('http://localhost:3000/events', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(event),
    })
      .then((response) => response.json())
      .then((newEvent) => setEvents([...events, newEvent]));
  };

  const deleteEvent = (id) => {
    if (window.confirm('Are you sure you want to delete this event?')) {
      fetch(`http://localhost:3000/events/${id}`, {
        method: 'DELETE',
      })
        .then(() => setEvents(events.filter((event) => event.id !== id)));
    }
  };

  const selectEvent = (eventId) => {
    const event = events.find((event) => event.id === eventId);
    setSelectedEvent(event);
  };

  return (
    <div className="container">
      <h1>Event Manager</h1>
      <EventForm onAdd={addEvent} />
      <EventList
        events={events}
        onDelete={deleteEvent}
        onSelect={selectEvent}
      />
      {selectedEvent && <EventDetails event={selectedEvent} />}
    </div>
  );
};

export default App;