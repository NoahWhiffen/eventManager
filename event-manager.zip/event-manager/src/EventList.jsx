import React from 'react';

const EventList = ({ events, onDelete, onSelect }) => {
  return (
    <div>
      <h2>Event List</h2>
      {events.length === 0 ? (
        <p>No events to show.</p>
      ) : (
        events.map((event) => (
          <div key={event.id} className="event-item">
            <h3>{event.title}</h3>
            <p>{event.date} - {event.time}</p>
            <button onClick={() => onSelect(event.id)}>View Details</button>
            <button onClick={() => onDelete(event.id)}>Delete</button>
          </div>
        ))
      )}
    </div>
  );
};

export default EventList;